package livebos.plugins.doc.ext.ebs;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

import com.apex.form.doc.DocProcManager;
import com.apex.form.doc.DocProcessorRegister;

public class Activator implements BundleActivator {

	private static BundleContext context;

	static BundleContext getContext() {
		return context;
	}

	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext bundleContext) throws Exception {
		Activator.context = bundleContext;
		DocProcessorRegister.getInstance().register(DocProcManager.DOC_SERVER_FILE, com.apex.form.doc.FileDocProcessor.class, MultiDocProcessorExt.class, com.apex.livebos.fs.FileFSIo.class);
	}

	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext bundleContext) throws Exception {
		DocProcessorRegister.getInstance().register(DocProcManager.DOC_SERVER_FILE, com.apex.form.doc.FileDocProcessor.class, com.apex.form.doc.MultiDocProcessor.class, com.apex.livebos.fs.FileFSIo.class);
	}

}
