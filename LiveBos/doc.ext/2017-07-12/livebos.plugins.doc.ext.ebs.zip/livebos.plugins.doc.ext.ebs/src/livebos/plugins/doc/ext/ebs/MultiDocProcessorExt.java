/**
 * 
 */
package livebos.plugins.doc.ext.ebs;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.Date;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.apex.form.Column;
import com.apex.form.DataAccess;
import com.apex.form.DocEntry;
import com.apex.form.FormObject;
import com.apex.form.MultiDocumentInfo;
import com.apex.form.SystemConfig;
import com.apex.form.UserContext;
import com.apex.form.doc.MultiDocProcessor;
import com.apex.form.transaction.Mission;
import com.apex.form.transaction.TransactionUtil;
import com.apex.form.util.FileUtil;
import com.apex.i18n.I18NUtil;
import com.apex.util.ApexDao;
import com.apex.util.ApexRowSet;
import com.apex.util.F;

/**
 * 光大投行项目支持, 多文档实际不删除，直接标记版本信息
 * 
 * 扩展多文档处理
 * 
 * @author 钟春林
 *
 */
public class MultiDocProcessorExt extends MultiDocProcessor {
	private static final String DELETE_SUFFIX = "_old";
	private static final Logger logger = Logger.getLogger(MultiDocProcessorExt.class);

	@Override
	public boolean deleteDocument(FormObject fmObj, Column[] cols) throws Exception {

		return super.deleteDocument(fmObj, cols);
	}

	@Override
	public boolean saveDocument(FormObject fmObj, Column[] cols) throws Exception {
		for (Column col : cols) {
			String filename = getDocumentName(fmObj, col);
			JSONArray deleted = null;
			try {
				final MultiDocumentInfo multiDoc = (MultiDocumentInfo) col.getDocument();
				logger.debug("begin to save multidoc:" + filename);
				for (Iterator<DocEntry> it = multiDoc.getEntries().iterator(); it.hasNext();) {
					final DocEntry docEntry = it.next();
					logger.debug("entry:" + docEntry.getId() + "[" + docEntry.getFilename() + "]/state:"
							+ docEntry.getState());
					if (docEntry.getState() == DocEntry.STATE_CANCEL) {
						continue;
					} else if (docEntry.getState() == DocEntry.STATE_DELETE) {
						final File file = new File(FileUtil.formatPath(filename) + docEntry.getId());
						if (file.exists()) {
							if (deleted == null) {
								deleted = new JSONArray();
							}
							JSONArray deletedEntry = new JSONArray();
							String delEntryId = docEntry.getId(); //+ DELETE_SUFFIX;
							deletedEntry.put(delEntryId);
							deletedEntry.put(docEntry.getFilename());
							deleted.put(deletedEntry);
//							TransactionUtil.registerMission(new Mission() {
//								@Override
//								public void complete() {
//									// --事务提交时才重命名
//									String destFilePathName = file.getAbsolutePath() + DELETE_SUFFIX;
//									File destFile = new File(destFilePathName);
//									file.renameTo(destFile);
//								}
//
//								@Override
//								public void abort() {
//								}
//
//							});

						}
						continue;
					} else if ((docEntry.getState() == DocEntry.STATE_NEW
							|| docEntry.getState() == DocEntry.STATE_NORMAL) && docEntry.getDocument() != null) {
						// --增加普通文档项判断,如果普通文档文档不存在(一般通过表达式赋值)则按新文档项进行判断
						final File file = new File(FileUtil.formatPath(filename) + docEntry.getId());
						if (docEntry.getState() == DocEntry.STATE_NEW || !file.exists()) {
							InputStream is = docEntry.getDocument().getInputStream();
							if (is != null) {
								FileOutputStream fout = new FileOutputStream(file);
								readAndWrite(is, fout);
								fout.close();
								TransactionUtil.registerMission(new Mission() {
									@Override
									public void complete() {
									}

									@Override
									public void abort() {
										// --事务回滚后删除刚写入的文件
										file.delete();
									}

								});
							}
						}

					}

				}
				multiDoc.reset();
				// multiDoc.close();
				TransactionUtil.registerMission(new Mission() {
					@Override
					public void complete() {
						multiDoc.close();
					}

					@Override
					public void abort() {

					}

				});
				logger.debug("deleted:" + deleted);
				if (deleted != null) {
					registRecordHistoryMission(fmObj, col, deleted);
				}
			} catch (FileNotFoundException e) {
				logger.warn(e, e);
				throw new SQLException(I18NUtil.getValue("error.doc.createfilefail"));
			} catch (IOException e) {
				logger.warn(e, e);
				throw new SQLException(I18NUtil.getValue("error.doc.writefileexception"));
			}
		}
		return true;
	}

	protected void registRecordHistoryMission(FormObject fmObj, Column col, JSONArray deleted) {
		final String tableName = fmObj.getTableName();
		final String colName = col.getName();
		final String id = fmObj.getIdentifier().getValue();
		final String datasourceName = SystemConfig.INSTANCE.getSysParam("livebos.plugins.doc.ext.his.datasource.name",
				"");
		final JSONArray deletedArray = deleted;
		final String userId = UserContext.getContext().getUser().getId();
		TransactionUtil.registerMission(new Mission() {

			@Override
			public void complete() {
				try {
					// String sql = "select FileHisStr from tIB_FileHis where
					// Tablename=? and FieldName=? and RecordID=?";
					// ApexDao dao = new ApexDao();
					// dao.prepareStatement(sql);
					// dao.setString(1, tableName);
					// dao.setString(2, colName);
					// dao.setString(3, id);
					// ApexRowSet rowSet =
					// dao.getRowSet(DataAccess.getDataSource(datasourceName));
					// if (rowSet.next()) {
					// String his = rowSet.getString(1);
					// JSONObject json = new JSONObject(his);
					// JSONArray optJSONArray = json.optJSONArray("items");
					// if (optJSONArray == null) {
					// optJSONArray = new JSONArray();
					// json.put("items", optJSONArray);
					// }
					// for (int i = 0; i < deletedArray.length(); i ++) {
					// optJSONArray.put(deletedArray.get(i));
					// }
					// StringBuilder updateSql = new StringBuilder();
					// updateSql.append("update tIB_FileHis set ");
					// updateSql.append("FileHisStr=?, OperateTime=?,
					// OperateUser=? ");
					// updateSql.append("where Tablename=? and FieldName=? and
					// RecordID=? ");
					// dao = new ApexDao();
					// dao.prepareStatement(updateSql.toString());
					// dao.setString(1, json.toString());
					// dao.setString(2, F.toString(new Date(), "yyyy-MM-dd
					// HH:mm:ss"));
					// dao.setString(3, userId);
					// dao.setString(4, tableName);
					// dao.setString(5, colName);
					// dao.setString(6, id);
					// dao.executeUpdate(DataAccess.getDataSource(datasourceName));
					// } else {
					JSONObject json = new JSONObject();
					json.put("items", deletedArray);
					StringBuilder insertSql = new StringBuilder();
					insertSql.append(
							"insert into tIB_FileHis(Tablename,FieldName,RecordID,FileHisStr,OperateTime,OperateUser) ");
					insertSql.append(" values (?,?,?,?,?,?)");
					ApexDao dao = new ApexDao();
					dao.prepareStatement(insertSql.toString());
					dao.setString(1, tableName);
					dao.setString(2, colName);
					dao.setString(3, id);
					dao.setString(4, json.toString());
					dao.setString(5, F.toString(new Date(), "yyyy-MM-dd HH:mm:ss"));
					dao.setString(6, userId);
					dao.executeUpdate(DataAccess.getDataSource(datasourceName));
					// }
				} catch (Exception e) {
					logger.error(e, e);
				}
			}

			@Override
			public void abort() {

			}
		});
	}

}
